<?php
session_start();
$dsn = "mysql:host=localhost;dbname=world_cup;charset=utf8";
$user_name = "root";
$password = "root";
$email = $_POST['email'];
$user_pw =$_POST['password'];
$_SESSION['mail'] = 0;


if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
$_SESSION['mail'] = 1;
header("Location: ./login.php");
}
try{
  $dbh = new PDO($dsn,$user_name,$password);
} catch(PDOException $e){
  $msg = $e->getMessage();
}

$sql = "SELECT * FROM users WHERE email = :email";
$stmt = $dbh->prepare($sql);
$stmt->bindValue(':email',$email);
$stmt->execute();
$member = $stmt->fetch();

$_SESSION['role']=$member['role'];
var_dump($_SESSION['role']);

if(password_verify($user_pw,$member['password'])){
  $_SESSION['id'] = $member['id'];
  $msg = 'ログインしました。';
  $link = '<a href="index.php">ホーム</a>';
}else{
  $msg = 'メールアドレスもしくはパスワードが間違っています。';
  $link = '<a href="login.php">戻る</a>';
}


 ?>
<h1><?php echo $msg;?></h1>
<?php echo $link; ?>
